# DAP_Project

Informatica Cloud folder contains mapping exports

Python code folder contains individual visualization, final result vizualization and dagster pipelines

accident data folder containts split files used for pushing data in MongoDB
